library(robustbase)
library(car)
library(doParallel)
library(foreach)
library(stabledist)

registerDoParallel(cores=48)

n <- 400
eta_id <- 4
B <- 1000

phi1_0 <- 0.3
psi1_0 <- 0.2
alpha0_0 <- 0.2
alpha1_0 <- 0.1
beta1_0 <- 0.3
theta_0 <- c(phi1_0, psi1_0, alpha0_0, alpha1_0, beta1_0)

## DGP
get_eta <- function(n, eta_id){
  if(eta_id == 1){
    eta <- rlogis(n, 0, 1)
  }
  if(eta_id == 2){
    eta <- rnorm(n, 0, 1.75)
  }
  if(eta_id == 3){
    eta <- runif(n, -2.85, 2.85)
  }
  if(eta_id == 4){
    eta <- 1.25*rt(n, 3)
  }
  if(eta_id == 5){
    eta <- 0.96*rt(n, 2)
  }
  if(eta_id == 6){
    eta <- rstable(n, alpha = 1.69, beta = 0)
  }
  
  return(eta)
}

get_ARMA_GARCH <- function(n, phi1, psi1, alpha0, alpha1, beta1, eta_id){
  eta <- get_eta(n, eta_id)
  y <- c()
  varep_t <- c()
  sigma_t <- c()
  y[1] <- 0
  varep_t[1] <- 0
  sigma_t[1] <- 0
  for(t in c(2:(n+1))){
    sigma_t[t] <- (alpha0 + alpha1*varep_t[t-1]^2 + 
                     beta1*sigma_t[t-1]^2)^(1/2)
    varep_t[t] <- eta[t-1]*sigma_t[t]
    y[t] <- phi1*y[t-1] + psi1*varep_t[t-1] + varep_t[t]
  }
  
  return(y)
}


## objective functions
g_fun <- function(y, theta){
  n <- length(y) - 1
  phi1 <- theta[1]
  psi1 <- theta[2]
  alpha0 <- theta[3]
  alpha1 <- theta[4]
  beta1 <- theta[5]
  varep_t <- c()
  g_t <- c()
  varep_t[1] <- 0
  g_t[1] <- 0
  for(t in c(2:(n+1))){
    varep_t[t] <- y[t] - phi1*y[t-1] - psi1*varep_t[t-1]
    g_t[t] <- phi1*y[t-1] + psi1*varep_t[t-1]
  }
  
  return(g_t[2:(n+1)])
}

sigma_fun <- function(y, theta){
  n <- length(y) - 1
  phi1 <- theta[1]
  psi1 <- theta[2]
  alpha0 <- theta[3]
  alpha1 <- theta[4]
  beta1 <- theta[5]
  varep_t <- c()
  sigma_t <- c()
  varep_t[1] <- 0
  sigma_t[1] <- 0
  for(t in c(2:(n+1))){
    varep_t[t] <- y[t] - phi1*y[t-1] - psi1*varep_t[t-1]
    sigma_t[t] <- (alpha0 + alpha1*varep_t[t-1]^2 + beta1*sigma_t[t-1]^2)^(1/2)
  }
  
  return(sigma_t[2:(n+1)])
}

f_fun <- function(x){
  x <- abs(x)
  fx <- exp(-x)/(1+exp(-x))^2
  
  return(fx)
}

q <- function(y, theta){
  n <- length(y) - 1
  ell_t <- -log(sigma_fun(y, theta)) + 
    log(f_fun((y[2:(n+1)]-g_fun(y, theta))/sigma_fun(y, theta)))
  
  return(ell_t)
}

## estimation
est_theta <- function(y){
  L_log <- function(theta){
    L <- -sum(q(y, theta))
    
    return(L)
  }
  theta_log <- try(optim(theta_0, fn = L_log)$par)
  if("try-error"%in% class(theta_log)){
    theta_log <- theta_0
  }
  
  return(theta_log)
}



######################
## experiment
######################

## for parallel computing
para.comp <- function(b, n, eta_id){
  if(b%%200 == 1){
    print(paste0("b=",b,"/",B))
  }
  
  y <- get_ARMA_GARCH(n, phi1_0, psi1_0, alpha0_0, alpha1_0, beta1_0, eta_id)
  theta_hat <- est_theta(y)
  bias <- theta_hat - theta_0
  
  return(bias)
}
set.seed(2024)

bias_mat <- matrix(NA, nrow = B, ncol = 5)
colnames(bias_mat) <- c("phi1", "psi1", "alpha0", "alpha1", "beta1")

## calculate results
bias_mat <- foreach(b = 1:B, .combine=rbind, 
                    .packages = c("car", "robustbase", "stabledist"), 
                    .verbose=FALSE) %dopar% para.comp(b, n, eta_id)
write.csv(round(bias_mat, 4), "./bias_mat.csv")


