

mydata <- read.csv("./bias_mat.csv")
mydata <- mydata[,c(2:6)]

par(mfrow=c(3,2), las = 1)

all_data <- 20 * unlist(mydata)
bin_width <- 0.5 
bin_edges <- seq(floor(min(all_data)), ceiling(max(all_data)), by = bin_width)

##################
## A
##################
data <- 20*mydata[,1]
hist(data, freq = FALSE, breaks = bin_edges/6*10, ylab = "", 
     xlim = c(-10,10), main = "", yim = c(0,0.2),
     xlab = expression(paste(sqrt(n),(widehat(phi)[paste(1,n)]-phi[1]))))
title("(a)", adj = 0)
x <- seq(-7, 7, length=100)
y <- dnorm(x, mean=0, sd=2.006)
lines(x, y, lwd=2)
legend('topright', lty = c(1), col = c(1),lwd=2, 
       legend = expression(N(0,2.006^2)))


##################
## B
##################
data <- 20*mydata[,2]
hist(data, breaks = bin_edges/6*8, freq = FALSE, ylab = "", 
     xlim = c(-8,8), main = "",
     xlab = expression(paste(sqrt(n),(widehat(varphi)[paste(1,n)]-varphi[1]))))
title("(b)", adj = 0)
x <- seq(-8, 8, length=100)
y <- dnorm(x, mean=0, sd=2.079)
lines(x, y, lwd=2)
legend('topright', lty = c(1), col = c(1),lwd=2, 
       legend = expression(N(0,2.079^2)))


##################
## C
##################
data <- 20*mydata[,3]
hist(data, breaks = bin_edges, freq = FALSE, ylab = "", 
     xlim = c(-6,6), main = "", 
     xlab = expression(paste(sqrt(n),(widehat(alpha)[paste(0,n)]-alpha[0]))))
title("(c)", adj = 0)
x <- seq(-6, 6, length=100)
y <- dnorm(x, mean=0, sd=1.441)
lines(x, y, lwd=2)
legend('topright', lty = c(1), col = c(1),lwd=2, 
       legend = expression(N(0,1.441^2)))



##################
## D
##################
data <- 20*mydata[,4]
hist(data, breaks = bin_edges/2, freq = FALSE, ylab = "", 
     xlim = c(-3,3), main = "", 
     xlab = expression(paste(sqrt(n),(widehat(alpha)[paste(1,n)]-alpha[1]))))
title("(d)", adj = 0)
x <- seq(-3, 3, length=100)
y <- dnorm(x, mean=0, sd=0.877)
lines(x, y, lwd=2)
legend('topright', lty = c(1), col = c(1),lwd=2, 
       legend = expression(N(0,0.877^2)))



##################
## E
##################
data <- 20*mydata[,5]
hist(data, breaks = bin_edges*2, freq = FALSE, ylab = "", 
     xlim = c(-12,12), main = "", 
     xlab = expression(paste(sqrt(n),(widehat(beta)[paste(1,n)]-beta[1]))))
title("(e)", adj = 0)
x <- seq(-12, 12, length=100)
y <- dnorm(x, mean=0, sd=3.503)
lines(x, y, lwd=2)
legend('topright', lty = c(1), col = c(1),lwd=2, 
       legend = expression(N(0,3.503^2)))




