library(robustbase)
library(car)
library(doParallel)
library(foreach)
library(stabledist)
library(numDeriv)
library(Rsolnp)

registerDoParallel(cores=48)

n_list <- c(100, 200, 400)
eta_list <- c(1)
B <- 1000

alpha0_0 <- 0.2
alpha1_0 <- 0.3
beta1_0 <- 0.3
theta_0 <- c(alpha0_0, alpha1_0, beta1_0)
theta <- 1*theta_0

R <- matrix(c(1, 2, 4), nrow = 1)
r_0 <- R%*%theta_0
r <- R%*%theta
d <- length(theta_0)
q <- nrow(R)
alpha <- 0.05

## DGP
get_eta <- function(n, eta_id){
  if(eta_id == 4){
    eta <- rlogis(n, 0, 1)
  }
  if(eta_id == 2){
    eta <- rnorm(n, 0, 1.75)
  }
  if(eta_id == 3){
    eta <- runif(n, -2.85, 2.85)
  }
  if(eta_id == 1){
    eta <- 1.25*rt(n, 3)
  }
  if(eta_id == 5){
    eta <- 0.96*rt(n, 2)
  }
  if(eta_id == 6){
    eta <- rstable(n, alpha = 1.69, beta = 0)
  }
  
  return(eta)
}

get_GARCH <- function(n, theta, eta_id){
  alpha0 <- theta[1]
  alpha1 <- theta[2]
  beta1 <- theta[3]
  
  eta <- get_eta(n, eta_id)
  y <- c()
  sigma_t <- c()
  y[1] <- 0
  sigma_t[1] <- 0
  for(i in c(2:(n+1))){
    sigma_t[i] <- (alpha0 + alpha1*y[i-1]^2 + beta1*sigma_t[i-1]^2)^(1/2)
    
    y[i] <- eta[i-1]*sigma_t[i]
  }
  
  return(y)
}

## objective functions
sigma_fun <- function(y, theta){
  n <- length(y) - 1
  alpha0 <- theta[1]
  alpha1 <- theta[2]
  beta1 <- theta[3]
  sigma_t <- c()
  sigma_t[1] <- 0
  for(i in c(2:(n+1))){
    sigma_t[i] <- (alpha0 + alpha1*y[i-1]^2 + beta1*sigma_t[i-1]^2)^(1/2)
  }
  
  return(sigma_t[2:(n+1)])
}

f_fun <- function(x){
  x <- abs(x)
  fx <- exp(-x)/(1+exp(-x))^2
  
  return(fx)
}

## estimation
est_theta <- function(y){
  q_fun <- function(theta){
    n <- length(y) - 1
    ell_t <- -log(sigma_fun(y, theta)) + 
      log(f_fun(y[2:(n+1)]/sigma_fun(y, theta)))
    
    return(ell_t)
  }
  
  L_log <- function(theta){
    L <- -sum(q_fun(theta))
    
    return(L)
  }
  theta_log <- try(optim(theta, fn = L_log, method = "L-BFGS-B",
                         lower = rep(0.01, d))$par)
  if("try-error"%in% class(theta_log)){
    theta_log <- theta
  }
  
  A_hat <- matrix(0, nrow = d, ncol = d)
  B_hat <- matrix(0, nrow = d, ncol = d)
  for(t in c(1:n)){
    qt_fun <- function(theta){
      n <- length(y) - 1
      ell <- -log(sigma_fun(y, theta)) + 
        log(f_fun(y[2:(n+1)]/sigma_fun(y, theta)))
      ell_t <- ell[t]
      
      return(ell_t)
    }
    st_fun <- grad(qt_fun, theta_log)
    ht_fun <- -hessian(qt_fun, theta_log)
    A_hat <- A_hat + ht_fun
    B_hat <- B_hat + st_fun%*%t(st_fun)
  }
  A_hat <- A_hat / n
  B_hat <- B_hat / n
  T_W <- n*t((R%*%theta_log - r_0))%*%
    solve(R%*%solve(A_hat)%*%B_hat%*%solve(A_hat)%*%t(R))%*%
    (R%*%theta_log - r_0)
  
  
  
  ##############################
  ## constraints
  ##############################
  constraint_function <- function(theta) {
    return(R%*%theta - r_0)
  }
  
  suppressWarnings({
    theta_check <- try(solnp(pars = theta, fun = L_log,
                             eqfun = constraint_function, 
                             eqB = 0, LB = rep(0.01, d),
                             control = list(trace = 0))$pars)
    if("try-error"%in% class(theta_check)){
      theta_check <- theta
    }
  })
  
  A_check <- matrix(0, nrow = d, ncol = d)
  B_check <- matrix(0, nrow = d, ncol = d)
  R_lambda <- matrix(0, nrow = d, ncol = 1)
  for(t in c(1:n)){
    qt_fun <- function(theta){
      n <- length(y) - 1
      ell <- -log(sigma_fun(y, theta)) + 
        log(f_fun(y[2:(n+1)]/sigma_fun(y, theta)))
      ell_t <- ell[t]
      
      return(ell_t)
    }
    st_fun <- grad(qt_fun, theta_check)
    ht_fun <- -hessian(qt_fun, theta_check)
    A_check <- A_check + ht_fun
    B_check <- B_check + st_fun%*%t(st_fun)
    R_lambda <- R_lambda - st_fun
  }
  A_check <- A_check / n
  B_check <- B_check / n
  R_lambda <- R_lambda / n
  T_LM <- n*t(R_lambda)%*%solve(A_check)%*%t(R)%*%
    solve(R%*%solve(A_check)%*%B_check%*%solve(A_check)%*%t(R))%*%
    R%*%solve(A_check)%*%R_lambda
  
  return(c(T_W, T_LM))
}



######################
## experiment
######################

## for parallel computing
para.comp <- function(b, n, eta_id){
  if(b%%200 == 1){
    print(paste0("b=",b,"/",B))
  }
  
  y <- get_GARCH(n, theta, eta_id)
  T_n <- est_theta(y)
  T_W <- T_n[1]
  T_LM <- T_n[2]
  thres <- qchisq(1-alpha,q)
  reject <- as.numeric(T_n > thres)
  
  return(reject)
}

results.reject <- matrix(NA, nrow = length(n_list)*length(eta_list), 
                       ncol = 2)
rownames(results.reject) <- rep(c("n=100", "n=200", "n=400"), length(eta_list))
colnames(results.reject) <- c("Wald", "LM")
results_sd <- results.reject

set.seed(2024)
for(n_id in 1:length(n_list)){
  n <- n_list[n_id]
  
  for(eta_id in eta_list){
    print(paste0("n_id = ",n_id,", eta.id = ", eta_id))
    
    reject_mat <- matrix(NA, nrow = B, ncol = 2)
    colnames(reject_mat) <- c("wald", "LM")
    
    ## calculate results
    reject_mat <- foreach(b = 1:B, .combine=rbind, 
                        .packages = c("car", "robustbase", "stabledist", 
                                      "numDeriv", "Rsolnp"), 
                        .verbose=FALSE) %dopar% para.comp(b, n, eta_id)
    
    results.reject[(eta_id-1)*length(n_list)+n_id, ] <- 
      abs(apply(reject_mat, 2, mean))
    
  }
}


write.csv(round(results.reject, 4), "./results.reject.csv")

