library(robustbase)
library(car)
library(doParallel)
library(foreach)
library(stabledist)

registerDoParallel(cores=48)

n_list <- c(100, 200, 400)
eta_list <- c(1:6)
B <- 1000

phi0_0 <- 0.5
phi1_0 <- 0.2
alpha0_0 <- 1
alpha1_0 <- 0.3
theta_0 <- c(phi0_0, phi1_0, alpha0_0, alpha1_0)

## DGP
get_eta <- function(n, eta_id){
  if(eta_id == 1){
    eta <- rlogis(n, 0, 1)
  }
  if(eta_id == 2){
    eta <- rnorm(n, 0, 1.75)
  }
  if(eta_id == 3){
    eta <- runif(n, -2.85, 2.85)
  }
  if(eta_id == 4){
    eta <- 1.25*rt(n, 3)
  }
  if(eta_id == 5){
    eta <- 0.96*rt(n, 2)
  }
  if(eta_id == 6){
    eta <- rstable(n, alpha = 1.69, beta = 0)
  }
  
  return(eta)
}

get_DAR <- function(n, phi0, phi1, alpha0, alpha1, eta_id){
  eta <- get_eta(n, eta_id)
  y <- c()
  y[1] <- 0
  for(i in c(2:(n+1))){
    y[i] <- phi0 + phi1*y[i-1] + 
      eta[i-1]*(alpha0 + alpha1*y[i-1]^2)^(1/2)
  }
  
  return(y)
}


## objective functions
sigma_fun <- function(y, theta){
  phi0 <- theta[1]
  phi1 <- theta[2]
  alpha0 <- theta[3]
  alpha1 <- theta[4]
  sigma_t <- (alpha0 + alpha1*y^2)^(1/2)
  
  return(sigma_t)
}

g_fun <- function(y, theta){
  phi0 <- theta[1]
  phi1 <- theta[2]
  alpha0 <- theta[3]
  alpha1 <- theta[4]
  g_t <- phi0 + phi1*y
  
  return(g_t)
}

f_fun <- function(x){
  x <- abs(x)
  fx <- exp(-x)/(1+exp(-x))^2
  
  return(fx)
}

q <- function(y, theta){
  n <- length(y) - 1
  ell_t <- -log(sigma_fun(y[1:n], theta)) + 
    log(f_fun((y[2:(n+1)]-g_fun(y[1:n], theta))/sigma_fun(y[1:n], theta)))
  
  return(ell_t)
}

## estimation
est_theta <- function(y){
  L_log <- function(theta){
    L <- -sum(q(y, theta))
    
    return(L)
  }
  theta_log <- try(optim(theta_0, fn = L_log)$par)
  if("try-error"%in% class(theta_log)){
    theta_log <- theta_0
  }
  
  return(theta_log)
}



######################
## experiment
######################

## for parallel computing
para.comp <- function(b, n, eta_id){
  if(b%%200 == 1){
    print(paste0("b=",b,"/",B))
  }
  
  y <- get_DAR(n, phi0_0, phi1_0, alpha0_0, alpha1_0, eta_id)
  theta_hat <- est_theta(y)
  
  return(theta_hat)
}

results_bias <- matrix(NA, nrow = length(n_list)*length(eta_list), 
                       ncol = 4)
rownames(results_bias) <- rep(c("n=200", "n=400", "n=800"), length(eta_list))
colnames(results_bias) <- c("phi0", "phi1", "alpha0", "alpha1")
results_sd <- results_bias

set.seed(2024)
for(n_id in 1:length(n_list)){
  n <- n_list[n_id]
  
  for(eta_id in eta_list){
    print(paste0("n_id = ",n_id,", eta.id = ", eta_id))
    
    theta_hat_mat <- matrix(NA, nrow = B, ncol = 4)
    colnames(theta_hat_mat) <- c("phi0", "phi1", "alpha0", "alpha1")
    
    ## calculate results
    theta_hat_mat <- foreach(b = 1:B, .combine=rbind, 
                        .packages = c("car", "robustbase", "stabledist"), 
                        .verbose=FALSE) %dopar% para.comp(b, n, eta_id)
    
    results_bias[(eta_id-1)*length(n_list)+n_id, ] <- 
      abs(theta_0 - apply(theta_hat_mat, 2, mean))
    results_sd[(eta_id-1)*length(n_list)+n_id, ] <- 
      apply(theta_hat_mat, 2, sd)
  }
}


write.csv(round(results_bias, 4), "./results_bias.csv")
write.csv(round(results_sd, 4), "./results_sd.csv")




