#!/bin/bash
#SBATCH -p queue
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 48
export PATH=/public1/home/scf0348/miniconda3/bin:$PATH
source activate R
srun Rscript code.R